package map.test;

public class JsonProduct {

}
