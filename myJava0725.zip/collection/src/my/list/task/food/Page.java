package my.list.task.food;

public class Page {
	public static void main(String[] args) {
		MyFood rice = new MyFood("볶음밥", 9000, "한식");
		MyFood jajangmyeon = new MyFood("짜장면", 8000, "중식");
		MyFood sushi = new MyFood("초밥", 18000, "일식");
		MyFood pasta = new MyFood("스파게티", 13000, "양식");
		
		
		
	}
}
