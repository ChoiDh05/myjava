package my.list.task.food;

import java.util.ArrayList;

import list.task.DBConnecter;

//- 음식 추가
//- 음식 이름으로 음식 종류 조회
//- 사용자가 원하는 종류의 음식 전체 조회
//- 음식 종류 수정 후 가격 10% 상승
//- 사용자가 원하는 종류의 음식 개수 조회

// 음식이름으로 조회 기능 구현
