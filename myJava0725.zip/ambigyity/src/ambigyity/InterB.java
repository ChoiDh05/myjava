package ambigyity;

public interface InterB {
	default void printName() {
		System.out.println("InterB");
}
}