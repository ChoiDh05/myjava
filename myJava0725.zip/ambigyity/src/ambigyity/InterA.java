package ambigyity;

public interface InterA {
	default void printName() {
		System.out.println("InterA");
	}
}
