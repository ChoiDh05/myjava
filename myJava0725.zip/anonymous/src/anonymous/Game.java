package anonymous;

public interface Game {
   public void play();
   public void exit();
}
