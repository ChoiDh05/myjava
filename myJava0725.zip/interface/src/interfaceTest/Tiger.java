package interfaceTest;

public class Tiger extends AnimalAdapter{

		@Override
	public void poop() {
		// TODO Auto-generated method stub
		
	}

}
