package markerTest;

//	초식동물
public interface HerbivoreMarker {;}
