package markerTest;

public class Dog extends Animal{

}
