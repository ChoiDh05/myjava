package controlStatementTest;

public class ForTest {
	public static void main(String[] args) {
//		이름 10번 출력
//		for(int i=0; i<10; i+=1) {
//			System.out.println(i+1+".최대환");
		
//		이름 10번 출력, 단 번호는 10~1로 출력되게하라
//		for(int i=10; i>0; i--) {
//			System.out.println(i + ".최대환");
//		}
		  for (int i = 0; i < 10; i++) {
		         System.out.println(10 - i + ".한동석"); 
	}
}
	}
