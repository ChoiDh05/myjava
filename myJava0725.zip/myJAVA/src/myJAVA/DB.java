package myJAVA;

import java.util.ArrayList;

public class DB {

	protected DB() {;}
	
	public static ArrayList<DB> db = new ArrayList<DB>();
}
