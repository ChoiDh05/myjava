package myJAVA;

public class Page {

}
