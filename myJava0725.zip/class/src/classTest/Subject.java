package classTest;

public class Subject {
   String name;
   int score;
   
   public Subject(String name, int score) {
      this.name = name;
      this.score = score;
   }
}