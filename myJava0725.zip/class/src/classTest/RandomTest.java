package classTest;

import java.util.Random;

public class RandomTest {
	public static void main(String[] args) {
		Random random =new Random();
		
	}
}
