package accessTest2;

import accessTest.AccessTest1;

public class AccessTest2 extends AccessTest1 {
public static void main(String[] args) {
	AccessTest1 access1 = new AccessTest1();
	AccessTest2 access2 = new AccessTest2();
	access2.
}
}
