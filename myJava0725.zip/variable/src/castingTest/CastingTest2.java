package castingTest;

public class CastingTest2 {
	public static void main(String[] args) {
		//자동 형변환 (아스키코드)
		char data = 48;
		System.out.println(data+10);
		System.out.println('A'+20);
		
		// 강제 형변환
		System.out.println((char)50);
	}

}
