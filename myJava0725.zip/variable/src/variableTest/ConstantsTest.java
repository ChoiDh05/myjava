package variableTest;

public class ConstantsTest {
	public static void main(String[] args) {
		final int ON = 187568;
		final int OFF = 187458;
		
		// 0: 로그인 실패, 1: 로그인 성공, 2: 관리자
		final int LOGIN_FAIL_STATUS = 0;
		final int LOGIN_SUCCESS_STATUS = 1;
		final int LOGIN_ADMIN_STATUS = 2;
	}
}
