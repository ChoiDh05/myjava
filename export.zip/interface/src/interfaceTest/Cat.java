package interfaceTest;

public class Cat implements Animal{

	@Override
	public void showHands() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sotDown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void waitNow() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void poop() {
		// TODO Auto-generated method stub
		
	}

}
