package db;

import java.util.ArrayList;

import myJAVA.PC;

public class DB {

	protected DB() {;}
	
	public static ArrayList<PC> db = new ArrayList<PC>();
}
