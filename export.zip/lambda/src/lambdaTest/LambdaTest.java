package lambdaTest;

public class LambdaTest {
	private void name() {
	LambdaInter lambdaInter = (number) -> number % 10 == 0; 
	}
}
