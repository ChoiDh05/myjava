package arrayTest;

public class ArTest1 {
	public static void main(String[] args) {
//		int[] arData = {2, 4, 5, 6, 8};
//		
//		System.out.println(arData);
//		System.out.println(arData[0]);
//		System.out.println(arData.length);
//		
//		System.out.println("==============");
		
//		첫 번째 값부터 순서대로 출력
//		for (int i = 0; i < arData.length; i++) {
//			System.out.print(arData[i]);
			
//		선언 시, 어떤 값이 들어갈 지는 모르지만 5칸이 필요하다는 것은 안다
//		5, 4, 3, 2, 1을 각방에 넣고 출력
		
//		int[] arData = new int[5];
//		
//		
//		for (int i = 0; i < arData.length; i++) {
//			arData[i]= 5-i;
//			System.out.println(arData[i]);
//			
//		}
		 int[] arData = new int[100];
      for (int i = 0; i < 50; i++) {
      System.out.println(arData[i * 2]);
   }

		}
}

