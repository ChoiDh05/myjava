package arrayTest;

public class MyArrayTest {
public static void main(String[] args) {


}
