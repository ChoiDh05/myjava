package accessTest;

public class AccessTest {
	public static void main(String[] args) {
		AccessTest1 accessTest1 = new AccessTest1();
		accessTest1.
	}
}
