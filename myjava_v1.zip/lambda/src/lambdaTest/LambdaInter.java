package lambdaTest;

@FunctionalInterface
public interface LambdaInter {
//	10의 배수인지 검사하는 추상메소드
public boolean checkMulitipleOf10(int number);
}
